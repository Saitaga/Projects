<?php
// Include database connection
include "db_connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve post data
    $title = $_POST["title"];
    $content = $_POST["content"];
    $username = $_POST["username"];

    // Insert post into database
    $sql = "INSERT INTO posts (title, content,username) VALUES (?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $title, $content,$username);
    $stmt->execute();

    // Check if insertion was successful
    if ($stmt->affected_rows > 0) {
        echo "Post created successfully.";
    } else {
        echo "Error creating post.";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
