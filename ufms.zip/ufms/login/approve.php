<?php
$approved = false;
$conn = mysqli_connect("localhost", "root", "", "auth_db");
$sql = "SELECT approved FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $approved = $row["approved"];
}
$stmt->close();
$conn->close();
?>
	<div class="phppot-container">
		<div class="page-header">
			<span class="login-signup"><a href="logout.php">Logout</a></span>
		</div>
		<div class="page-content">
			Welcome <?php echo $username;?>
            <?php if (!$approved): ?>
                <br><br>
                <button id="approve-btn" class="btn btn-success">Approve</button>
                <script>
                    document.getElementById('approve-btn').addEventListener('click', function() {
                        // Send an AJAX request to approve the user
                        fetch('approve.php?username=<?php echo $username; ?>')
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    alert('User has been approved!');
                                    // Reload the page to show the updated status
                                    location.reload();
                                } else {
                                    alert('Error approving user.');
                                }
                            });
                    });
                </script>
            <?php endif; ?>
		</div>
	</div>