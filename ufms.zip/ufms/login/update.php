<?php
include 'connection.php';
include 'header.php';

// Check if updateid is set in the URL
if (isset($_GET['updateid'])) {
    $id = $_GET['updateid'];

    // Fetch existing project details
    $sql_fetch = "SELECT * FROM project WHERE id = $id";
    $result_fetch = $conn->query($sql_fetch);

    if ($result_fetch && $result_fetch->num_rows > 0) {
        $row = $result_fetch->fetch_assoc();
        $projectTitle = $row['projectTitle'];
        $studentName = $row['studentName'];
        $studentEmail = $row['studentEmail'];
        $course = $row['course'];
        $file = $row['file'];
    } else {
        echo "No project found with ID: $id";
        exit;
    }
}

// Handle form submission
if(isset($_POST['submit'])){
    // Retrieve form data
    $projectTitle = $_POST['projectTitle'];
    $studentName = $_POST['studentName'];
    $studentEmail = $_POST['studentEmail'];
    $course = $_POST['course'];
    $chapterTitle = $_POST['chapterTitle']; // New field for chapter title

    // File handling
    $file_name = $_FILES["file"]["name"];
    $file_tmp = $_FILES["file"]["tmp_name"];
    $uploads_dir = 'uploads/';

    // Move uploaded file to uploads directory
    move_uploaded_file($file_tmp, $uploads_dir.$file_name);

    // Insert chapter into chapters table
    $sql_insert_chapter = "INSERT INTO chapters (project_id, chapter_title) VALUES (?, ?)";
    $stmt_chapter = $conn->prepare($sql_insert_chapter);
    $stmt_chapter->bind_param("is", $id, $chapterTitle);

    if ($stmt_chapter->execute()) {
        // Update project file in projects table
        $sql_update_project = "UPDATE project SET projectTitle=?, studentName=?, studentEmail=?, course=?, file=? WHERE id=?";
        $stmt_project = $conn->prepare($sql_update_project);
        $stmt_project->bind_param("sssssi", $projectTitle, $studentName, $studentEmail, $course, $file_name, $id);

        if ($stmt_project->execute()) {
            // Update successful, redirect to table.php
            header('location: table.php');
            exit;
        } else {
            echo "Error updating project: " . $conn->error;
        }
    } else {
        echo "Error inserting chapter: " . $conn->error;
    }
}

// Fetch existing chapters associated with the project
$sql_fetch_chapters = "SELECT * FROM chapters WHERE project_id = $id";
$result_fetch_chapters = $conn->query($sql_fetch_chapters);
$existing_chapters = array();
if ($result_fetch_chapters && $result_fetch_chapters->num_rows > 0) {
    while ($row_chapter = $result_fetch_chapters->fetch_assoc()) {
        $existing_chapters[] = $row_chapter['chapter_title'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-back {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-back:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Update Project</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="projectTitle">Project Title:</label>
                <input type="text" class="form-control" id="projectTitle" name="projectTitle" 
                autocomplete="off" value="<?php echo $projectTitle;?>" placeholder="e.g. Learning Management System" required>
            </div>
            <div class="form-group">
                <label for="studentName">Student Name:</label>
                <input type="text" class="form-control" id="studentName" name="studentName" 
                autocomplete="off" value="<?php echo $studentName;?>" placeholder="e.g. Martin Maasai" required>
            </div>
            <div class="form-group">
                <label for="course">Course:</label>
                <select class="form-control" id="course" name="course" required>
                    <option value="" disabled>Select Course</option>
                    <option value="Computer Science" <?php if ($course == 'Computer Science') echo 'selected'; ?>>Computer Science</option>
                    <option value="Information Technology" <?php if ($course == 'Information Technology') echo 'selected'; ?>>Information Technology</option>
                    <option value="Business and Information Technology" <?php if ($course == 'Business and Information Technology') echo 'selected'; ?>>Business and Information Technology</option>
                    <!-- Add more options for courses -->
                </select>
            </div>
            <div class="form-group">
                <label for="studentEmail">Student Email:</label>
                <input type="email" class="form-control" id="studentEmail" name="studentEmail" 
                autocomplete="off" value="<?php echo $studentEmail;?>" placeholder="e.g. martinmaasai@gmail.com" required>
            </div>
            <div class="form-group">
                <label for="chapterTitle">Chapter Title:</label>
                <input type="text" class="form-control" id="chapterTitle" name="chapterTitle" 
                autocomplete="off" placeholder="e.g. Introduction" required>
            </div>
            <div class="form-group">
                <label for="file">Upload Project File:</label>
                <input type="file" class="form-control-file" id="file" name="file" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Update</button>
            <button class="btn btn-back"><a href="table.php" class="text-light">Back</a></button>
        </form>
    </div>
</body>
</html>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
