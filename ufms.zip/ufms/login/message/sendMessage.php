<?php

require_once "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <!-- Consolidate CSS imports -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-jka+I6z+RJ/owRXvqIeGph1wR+Qe1vb6k4VfvDyOoefxO6YFfBO+q+6DWK+uZzWu" crossorigin="anonymous">
    
</head>
<body>

<br><br><br>
<div class="chat-container">
    <div class="logo-container">
        <img src="chat.jpg" alt="Logo" class="logo">
    </div>

    <div class="chat-messages" id="chat-messages">
        <!-- Chat messages will be displayed here -->
    </div>

<form id="chat-form">
<label for="file-input" id="file-label" class="file-label">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paperclip" viewBox="0 0 16 16">
            <path d="M4.5 3a2.5 2.5 0 0 1 5 0v9a1.5 1.5 0 0 1-3 0V5a.5.5 0 0 1 1 0v7a.5.5 0 0 0 1 0V3a1.5 1.5 0 1 0-3 0v9a2.5 2.5 0 0 0 5 0V5a.5.5 0 0 1 1 0v7a3.5 3.5 0 1 1-7 0z"/>
        </svg>
    </label>
    <input type="file" id="file-input" name="file" class="file-input" style="display: none;">
    <input type="text" id="message" name="message" placeholder="Message..." style="border-radius: 14px;">
    
    <button type="submit" id="send-btn">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
            <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76z"/>
        </svg>
    </button>
</form>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-DhYQ8FOb+fO/zB/jkuJbPrpwYNr7+1NbJUZPt4OOg8I5GYaNwFkfpf/Kzqmj5zF2" crossorigin="anonymous"></script>

<script>
    document.getElementById('chat-form').addEventListener('submit', function(event) {
    event.preventDefault();
    sendMessage();
});

// Remove the click event listener on the send button
// document.getElementById('send-btn').addEventListener('click', function() {
//     sendMessage();
// });

function sendMessage() {
    var message = document.getElementById('message').value.trim();
    if (message === '') return;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'send_message.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
            document.getElementById('message').value = '';
            updateChatArea();
        }
    };
    xhr.send('message=' + encodeURIComponent(message));
}

// Rest of your JavaScript code remains unchanged
function updateChatArea() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_messages.php', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
                var messages = JSON.parse(xhr.responseText);
                var chatMessages = document.getElementById('chat-messages');
                chatMessages.innerHTML = '';
                var messageCount = 0;
                messages.forEach(function(messageObj) {
                    var messageContent = messageObj.message;
                    var sentAt = new Date(messageObj.sent_at);
                    var messageTime = sentAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                    var messageDiv = document.createElement('div');
                    messageDiv.classList.add('message');
                    var messageContentDiv = document.createElement('div');
                    messageContentDiv.classList.add('message-content');
                    messageContentDiv.textContent = messageContent;
                    messageDiv.appendChild(messageContentDiv);
                    var messageTimeDiv = document.createElement('div');
                    messageTimeDiv.classList.add('message-time');
                    messageTimeDiv.textContent = messageTime;
                    messageDiv.appendChild(messageTimeDiv);

                    if (messageObj.file_url) {
                        var fileLink = document.createElement('a');
                        fileLink.href = messageObj.file_url;
                        fileLink.textContent = messageObj.file_name;
                        messageDiv.appendChild(document.createElement('br')); // Add line break
                        messageDiv.appendChild(fileLink);
                    }

                    if (messageCount % 2 === 0) {
                        messageDiv.classList.add('left');
                    } else {
                        messageDiv.classList.add('right');
                    }

                    chatMessages.appendChild(messageDiv);
                    messageCount++;
                });
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        };
        xhr.send();
    }

    setInterval(updateChatArea, 1000);
    
</script>


<style>
    /* Base styles */
    .chat-container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
    }

    .chat-messages {
        max-height: 300px;
        overflow-y: auto;
    }

    .message {
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        font-size: 14px;
        max-width: 70%;
        word-wrap: break-word;
    }

    .message.left {
        background-color: #f2f2f2;
        border-top-left-radius: 0;
    }

    .message.right {
        background-color: #c8e6c9;
        border-top-right-radius: 0;
    }

    .message-content {
        padding: 5px;
    }

    .message-time {
        font-size: 12px;
        color: #999;
        margin-top: 5px;
    }

    /* Alternate message colors */
    .even-message {
        background-color: #ffcdd2;
    }

    .odd-message {
        background-color: #c8e6c9;
    }

    .logo-container {
        text-align: center;
        margin-bottom: 20px;
    }

    .logo {
        max-width: 100px;
        height: auto;
    }

    /* Gray send button */
    #send-btn {
        background-color: #ccc;
    }

    /* Custom file input button */
    .file-label {
        cursor: pointer;
        display: inline-block;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        color: #555;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 4px;
        transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    }

    .file-label:hover {
        border-color: #333;
    }

    .file-input {
        display: none;
    }
    /* Reduce the size of the scrollbar */
.chat-messages::-webkit-scrollbar {
    width: 2px; /* Width of the scrollbar */
}

/* Track */
.chat-messages::-webkit-scrollbar-track {
    background: #f1f1f1; /* Color of the track */
}

/* Handle */
.chat-messages::-webkit-scrollbar-thumb {
    background: #888; /* Color of the handle */
}

/* Handle on hover */
.chat-messages::-webkit-scrollbar-thumb:hover {
    background: #555; /* Color of the handle on hover */
}

</style>

</body>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
</html>
