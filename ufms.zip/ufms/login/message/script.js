document.getElementById('send-btn').addEventListener('click', sendMessage);

function sendMessage() {
    var message = document.getElementById('message').value.trim();
    if (message === '') {
        alert('Please enter a message.');
        return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'send_message.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
            // Clear input field after sending message
            document.getElementById('message').value = '';
            updateChatArea(); // Update chat area after sending message
        }
    };
    xhr.send('message=' + encodeURIComponent(message));
}

// Function to update chat area with received messages
function updateChatArea() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'get_messages.php', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
            var messages = JSON.parse(xhr.responseText);
            var chatMessages = document.getElementById('chat-messages');
            chatMessages.innerHTML = ''; // Clear previous messages

            var currentDate = '';
            messages.forEach(function(messageObj) {
                var message = messageObj.message;
                var sentAt = new Date(messageObj.sent_at);
                var messageTime = sentAt.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                var messageDate = sentAt.toLocaleDateString();

                if (currentDate !== messageDate) {
                    chatMessages.innerHTML += '<div class="date-separator">' + messageDate + '</div>';
                    currentDate = messageDate;
                }

                chatMessages.innerHTML += '<div class="message">' + message + ' <span class="time">' + messageTime + '</span></div>';
            });

            // Scroll to the bottom of chat area
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    };
    xhr.send();
}
