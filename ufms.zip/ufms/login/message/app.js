// app.js

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const session = require('express-session');

const app = express();
const port = 3000;

// MongoDB connection setup
mongoose.connect('mongodb://localhost:27017/chatapp', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// Define user schema and model
const userSchema = new mongoose.Schema({
    username: String,
    password: String
});
const User = mongoose.model('User', userSchema);

// Define message schema and model
const messageSchema = new mongoose.Schema({
    content: String,
    sender: String,
    timestamp: { type: Date, default: Date.now }
});
const Message = mongoose.model('Message', messageSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({ secret: 'secret-key', resave: true, saveUninitialized: true }));

// Routes

// Register route
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword });
    await newUser.save();
    // Redirect to login page after successful registration
    res.redirect('/login');
});

// Login route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) {
        res.status(401).send('Invalid username or password');
    } else {
        const validPassword = await bcrypt.compare(password, user.password);
        if (validPassword) {
            req.session.userId = user._id;
            // Redirect to chat page after successful login
            res.redirect('/chat');
        } else {
            res.status(401).send('Invalid username or password');
        }
    }
});

// Logout route
app.post('/logout', (req, res) => {
    req.session.destroy();
    // Redirect to login page after logout
    res.redirect('/login');
});

// Chat route
app.get('/chat', (req, res) => {
    const userId = req.session.userId;
    if (!userId) {
        // Redirect to login page if not logged in
        res.redirect('/login');
    } else {
        // Render chat.html page
        res.sendFile(__dirname + '/chat.html');
    }
});

// Serve login.html for the login page
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

// Serve register.html for the register page
app.get('/register', (req, res) => {
    res.sendFile(__dirname + '/register.html');
});

// Serve static files (CSS, JS, etc.)
app.use(express.static('public'));

// Start server
app.listen(port, () => console.log(`Server running on port ${port}`));
