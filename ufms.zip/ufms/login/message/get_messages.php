<?php
include "connection.php";

// Initialize an empty array to store messages
$messages = [];

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve messages from the database
$sql = "SELECT message, file_name, file_path, sent_at FROM messages ORDER BY sent_at ASC"; 
$result = $conn->query($sql);

if ($result === false) {
    // Handle query error
    die("Error retrieving messages: " . $conn->error);
}

if ($result->num_rows > 0) {
    // Fetch and store messages
    while ($row = $result->fetch_assoc()) {
        $messages[] = array(
            'message' => $row['message'],
            'file_name' => $row['file_name'],
            'file_path' => $row['file_path'],
            'sent_at' => $row['sent_at']
        );
    }
}

// Encode messages as JSON and output
echo json_encode($messages);

// Close connection
$conn->close();
?>
