<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
  <link rel="stylesheet" href="projects.css">
  <style>
    /* Add shadow to the dropdown menu */
    .dropdown-menu-container {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); 
    }
    /* Add background shadow */
    .header-container {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>
  <div class="header-container">
    <div class="d-flex justify-content-center mt-3">
    </div>
    <nav class="container-fluid mt-3">
      <div class="dropdown">
        <a href="../home.php" class="btn btn-secondary">Home</a>
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
          Menu
        </button>
        <ul class="dropdown-menu dropdown-menu-container" aria-labelledby="dropdownMenuButton">
          <li>
            <a class="dropdown-item" href="forum/index.php">
              <i class="fas fa-book-open me-2"></i> Guidelines
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="../table.php">
              <i class="fas fa-folder-open me-2"></i> Projects
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="../myProjects.php">
              <i class="fas fa-folder-open me-2"></i> My Projects
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="sendMessage.php">
              <i class="fas fa-comments me-2"></i> Chat
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="../forum.php">
              <i class="fas fa-users"></i>Forum
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="../edit.php">
              <i class="fas fa-user-edit me-2"></i> Profile
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="../logout.php">
              <i class="fas fa-sign-out-alt me-2"></i> Log Out
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
