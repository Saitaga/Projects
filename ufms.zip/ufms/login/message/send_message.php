<?php
include 'connection.php';

// Check if message is received
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['message'])) {
    $message = $_POST['message'];

    // Initialize file variables
    $file_name = '';
    $file_destination = '';

    // Handle file upload if file is received
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file_name = $_FILES['file']['name'];
        $file_tmp_name = $_FILES['file']['tmp_name'];
        $file_destination = 'uploads/' . $file_name; // Destination directory for uploaded files
        
        // Move uploaded file to destination
        if (move_uploaded_file($file_tmp_name, $file_destination)) {
            echo "File uploaded successfully.";
        } else {
            // Handle file upload error
            echo "Error uploading file.";
        }
    }

    // Insert message and file info into the database
    $sql = "INSERT INTO messages (message, file_name, file_path, sent_at) VALUES (?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);

    // Check if statement preparation succeeded
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        exit;
    }

    // Bind parameters to the prepared statement
    $stmt->bind_param("sss", $message, $file_name, $file_destination);

    // Execute SQL query
    if ($stmt->execute() === TRUE) {
        echo "Message sent successfully";
    } else {
        // Handle SQL execution error
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement
    $stmt->close();
} else {
    // Handle case where message is not received
    echo "Message is not received.";
}

// Close connection
$conn->close();
?>
