<?php
include "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the project ID and feedback text are provided
    if (isset($_POST['id']) && isset($_POST['feedback'])) {
        // Retrieve project ID and feedback text from the form
        $id = $_POST['id'];
        $feedback = $_POST['feedback'];

        // Prepare the SQL statement to insert feedback into the database
        $sql = "INSERT INTO feedback (id, feedback) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);

        // Bind the parameters and execute the statement
        $stmt->bind_param("is", $id, $feedback);
        if ($stmt->execute()) {
            // Feedback inserted successfully
            echo "Feedback submitted successfully!";
        } else {
            // Error occurred while inserting feedback
            echo "Error: Unable to submit feedback.";
        }
    } else {
        // Project ID or feedback text is missing
        echo "Error: Project ID or feedback is missing.";
    }
} else {
    // Invalid request method
    echo "Error: Invalid request method.";
}
?>
