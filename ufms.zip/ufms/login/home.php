<?php
include 'connection.php'; // Assuming this includes the file where $mysqli is defined
include 'header.php';

session_start();

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {

    // Include database connection
    include 'db_conn.php'; // Make sure this file contains the definition of $mysqli

    // Include other necessary files or functions
    include 'php/home.php';

    $user = getUserById($_SESSION['id'], $conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="projects.css">
   </head>
<body>
    <?php if ($user) { ?>
    <div class="d-flex justify-content-center align-items-center vh-100">
        
        <div class="shadow w-350 p-3 text-center">
            <!--<img src="uploads/<?=$user['pp']?>"
                 class="img-fluid rounded-circle">-->
                 <img src='LOGO2.png' alt='Logo' class='img-fluid' style='max-width: 150px; height: auto;'>
            
            <h3 class="display-4 "><?=$user['fname']?></h3>
            <a href="project.php" class="btn btn-primary">
                Add Project
            </a>
            <?php
             $id = $_SESSION['id'];
            echo "<button class='btn btn-success btn-view'><a href='grades.php?viewid=$id' class='text-light'>Grades</a></button>";
               ?>  
            <style>
                body{
                    background-color: whitesmoke;
                }
            </style>
        </div>
    </div>
    <div>

    <a href="message/sendMessage.php" class="chat-icon">
    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-chat-fill" viewBox="0 0 16 16">
        <path d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9 9 0 0 0 8 15"/>
    </svg>
</a>
<!-- <?php

// require_once "header.php";
?> -->

<style>
    /* Base styles */
    .chat-container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #fff;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s;
    }

    .chat-container-right {
        transform: translateX(250px);
    }

    .chat-messages {
        max-height: 300px;
        overflow-y: auto;
    }

    .message {
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        font-size: 14px;
        max-width: 70%;
        word-wrap: break-word;
    }

    .message.left {
        background-color: #f2f2f2;
        border-top-left-radius: 0;
    }

    .message.right {
        background-color: #c8e6c9;
        border-top-right-radius: 0;
    }

    .message-content {
        padding: 5px;
    }

    .message-time {
        font-size: 12px;
        color: #999;
        margin-top: 5px;
    }

    .logo-container {
        text-align: center;
        margin-bottom: 20px;
    }

    .logo {
        max-width: 100px;
        height: auto;
    }

    /* Gray send button */
    #send-btn {
        background-color: #ccc;
    }

    /* Custom file input button */
    .file-label {
        cursor: pointer;
        display: inline-block;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        color: #555;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 4px;
        transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    }

    .file-label:hover {
        border-color: #333;
    }

    .file-input {
        display: none;
    }
    /* Reduce the size of the scrollbar */
.chat-messages::-webkit-scrollbar {
    width: 2px; /* Width of the scrollbar */
}

/* Track */
.chat-messages::-webkit-scrollbar-track {
    background: #f1f1f1; /* Color of the track */
}

/* Handle */
.chat-messages::-webkit-scrollbar-thumb {
    background: #888; /* Color of the handle */
}

/* Handle on hover */
.chat-messages::-webkit-scrollbar-thumb:hover {
    background: #555; /* Color of the handle on hover */
}

</style>

<style>
.chat-icon {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #007bff;
    color: white;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    text-decoration: none;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s, box-shadow 0.3s;
}

.chat-icon:hover {
    transform: scale(1.1);
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
}
</style>
        <?php
        // Include database connection
        include 'connection.php'; 
        
        // Get all projects associated with the user's ID
        $id = $_SESSION['id'];
        $sql = "SELECT * FROM project WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Check if projects exist
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                
                
                echo "<style>
    /* Style the table */
    table {
        border-collapse: collapse;
        width: 100%;
        max-width: 800px;
        margin: 0 auto;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    /* Style table header */
    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    /* Style table header */
    th {
        background-color: #f2f2f2;
    }
</style>";

echo "<table>
    <tr>
        <th>Project Title:</th>
        <th>Course:</th>
        <th>Chapter:</th>
        <th>Status:</th>
        <th>Feedback:</th>
        <th>File:</th>
    </tr>
    
    <tr>
        <td>" . $row['projectTitle'] . "</td>
        <td>" . $row['course'] . "</td>
        <td>" . $row['chapter'] ."</td>";
        
        // Apply styles to the status text
        if ($row['status'] == 'approved') {
            echo "<td><span style='color: green;'>Approved</span></td>";
        } elseif ($row['status'] == 'rejected') {
            echo "<td><span style='color: red;'>Rejected</span></td>";
        } else {
            echo "<td>" .$row['status'] ."</td>";
        }
        
        echo "<td>" .$row['feedback'] ."</td>
        <td><a href='uploads/" . $row['file'] . "' target='_blank'>Download</a></td>
    </tr>
</table>";

            }
        
    
            
        } else {
            echo 'No projects found for this user.';
        }
        
        ?>
        
        <!-- Display feedback related to this project -->
        <?php
require_once('connection.php');

// Check if user ID is set in session
if (isset($_SESSION['id'])) {
    $userId = $_SESSION['id']; // Assuming user ID is stored in session

    // Prepare the query
    if (isset($userId)) { // If filtering by user ID
        $stmt = $conn->prepare("SELECT feedback FROM project WHERE id = ?");
        $stmt->bind_param("i", $userId); // Bind user ID as integer
    } else {
        $stmt = $conn->prepare("SELECT feedback FROM project"); // No filtering
    }

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if there are rows in the result
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
           
        }
    } else {
        echo "No feedback found.";
    }

    // Close statement
    $stmt->close();
} else {
    echo "User ID not set in session.";
}
?>
<?php

require_once('connection.php');

$sql = "SELECT * FROM project WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if projects exist
    if ($result->num_rows > 0) {
        while ($project = $result->fetch_assoc()) {
$projectId = $project['id'];
$sql_chapters = "SELECT * FROM chapters WHERE project_id = ?";
$stmt_chapters = $conn->prepare($sql_chapters);
$stmt_chapters->bind_param("i", $projectId);
$stmt_chapters->execute();
$result_chapters = $stmt_chapters->get_result();
if ($result_chapters->num_rows > 0) {
    while ($chapter = $result_chapters->fetch_assoc()) {
        
    }
} else {
    echo "No chapters found.";
}
        }
    }
?>

    <?php }else { 
     header("Location: login.php");
     exit;
    } ?>

<?php }else {
    header("Location: login.php");
    exit;
} ?>

</body>
</html>
<?php
include 'footer.php';
?>
