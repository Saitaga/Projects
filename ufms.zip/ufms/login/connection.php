<?php



$dbhost = "localhost";

$dbuser = "root";

$dbpass = "";

$dbname = "projects";



if(!$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname))

{



	die("failed to connect!");

}

      
        