<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Include database connection
require_once "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $project_id = $_POST['project_id'];
    $feedback = $_POST['feedback'];
    $admin_id = $_SESSION['admin_id'];

    // Insert feedback into the database
    $sql = "INSERT INTO feedback (project_id, feedback, admin_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isi", $project_id, $feedback, $admin_id);
    $stmt->execute();
    
    // Redirect back to the admin page or display a success message
    header("Location: admin_page.php");
    exit();
} else {
    header("Location: admin_page.php"); // Redirect if accessed directly
    exit();
}
?>
