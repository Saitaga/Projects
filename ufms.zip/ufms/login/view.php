<?php
include "connection.php";
include "header.php";

// Check if a project ID is provided in the URL
if (isset($_GET['viewid'])) {
    $id = $_GET['viewid'];

    // Prepare the SQL statement with a placeholder
    $sql = "SELECT * FROM project WHERE id = ?";
    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("i", $id);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if the project exists
    if ($result->num_rows > 0) {
        // Project found, display its details
        while($row = $result->fetch_assoc()) {
            echo "<div style='text-align: center; margin: 0 auto; max-width: 600px;'>";
            echo "<h2>Project Details</h2>";
            echo "<div style='text-align: left; padding: 20px; background-color: #f9f9f9; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'>";
            echo "<p><strong>Project Title:</strong> " . $row['projectTitle'] . "</p>";
            echo "<p><strong>Student Name:</strong> " . $row['studentName'] . "</p>";
            echo "<p><strong>Student Email:</strong> " . $row['studentEmail'] . "</p>";
            echo "<p><strong>Course:</strong> " . $row['course'] . "</p>";
            echo "<p><strong>Status:</strong>";
            if ($row['status'] == 'Approved') {
                echo "<td><span style='color: green;'>Approved</span></td>";
            } elseif ($row['status'] == 'Rejected') {
                echo "<td><span style='color: red;'>Rejected</span></td>";
            } else {
                echo "<td>{$row['status']}</td>";
            }
            
            echo "<p><strong>Description:</strong></p>";
            echo "<p>" . $row['description'] . "</p>";
            echo "<p><strong>File:</strong> " . $row['file'] . "</p>";
            
            echo "</div>";
            echo "</div>";
            echo "<a href=forum/chat.html class=btn btn-secondary footer-btn>Chat</a>";
           
            // Display the feedback form
            /*echo "<h2>Feedback</h2>
            <form id='feedbackForm' action='submit_feedback.php' method='post'>
                <input type='hidden' name='id' value='$id'>
                <textarea name='feedback' id='feedback' placeholder='Enter your feedback'></textarea>
                <br>
                <button type='submit'>Submit Feedback</button>
            </form>";*/
        }
    } else {
        echo '<div style="text-align: center;">No data found for project ID: ' . $id . '</div>';
    }
}    
?>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
