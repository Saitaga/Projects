<?php

use LDAP\Result;

session_start();
include 'header.php';
include 'connection.php';

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {
    // Get user ID from session
    $id = $_SESSION['id'];

    // Prepare the SQL statement with a placeholder
    $sql = "SELECT * FROM project WHERE id = ?";

    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("i", $id);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if the project exists
    if ($result->num_rows > 0) {
        // Project found, display its details
        while ($row = $result->fetch_assoc()) {
            echo "<div class='text-center' style='margin: 0 auto; max-width: 600px;'>";
            echo "<h2>Project Details</h2>";
            echo "<img src='LOGO2.png' alt='Logo' class='img-fluid' style='max-width: 100px; height: auto;'>";
            echo "<div style='text-align: left; padding: 20px; background-color: #f9f9f9; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'>";
            echo "<p><strong>Project Title:</strong> " . $row['projectTitle'] . "</p>";
            echo "<p><strong>Student Name:</strong> " . $row['studentName'] . "</p>";
            echo "<p><strong>Student Email:</strong> " . $row['studentEmail'] . "</p>";
            echo "<p><strong>Course:</strong> " . $row['course'] . "</p>";
            
            // Display status with color
            if ($row['status'] == 'Approved') {
                echo "<p><strong>Status:</strong> <span style='color: green;'>Approved</span></p>";
            } elseif ($row['status'] == 'Rejected') {
                echo "<p><strong>Status:</strong> <span style='color: red;'>Rejected</span></p>";
            } else {
                echo "<p><strong>Status:</strong> " . $row['status'] . "</p>";
            }

            echo "<p><strong>Description:</strong></p>";
            echo "<p>" . $row['description'] . "</p>";
            
            // Rest of the code remains unchanged

            // Check if the file exists
            if (!empty($row['file'])) {
                $file_path = 'uploads/' . $row['file'];
                $file_extension = pathinfo($file_path, PATHINFO_EXTENSION);

                // Display download link for the file
                echo "<p><strong>File:</strong> <a href='$file_path' target='_blank'>" . $row['file'] . "</a></p>";

                // Check if the file type is supported for embedding
                $embeddable_types = ['pdf', 'txt', 'jpg', 'jpeg', 'png', 'gif','docx'];
                if (in_array(strtolower($file_extension), $embeddable_types)) {
                    // Display embedded content for supported file types
                    echo "<embed src='$file_path' type='application/$file_extension' width='600' height='400'>";
                } else {
                    // Display a message for unsupported file types
                    echo "<p>This file type is not supported for embedding. Please download to view.</p>";
                }
            } else {
                echo "<p><strong>File:</strong> No file attached.</p>";
            }

            echo "<p><strong>Feedback:</strong></p>";
            echo "<p>" . $row['feedback'] . "</p>";

            // Add buttons for update and delete with confirmation dialog
          // Add buttons for update and delete with confirmation dialog
echo "<button class='btn btn-secondary'><a href='update.php?updateid=" . $row['id'] . "' class='text-light'>Update</a></button>";
// echo "<button class='btn btn-danger'><a href='delete.php?deleteid=" . $row['id'] . "' class='text-light'>Delete</a></button>";

// JavaScript function to confirm delete
echo "<button class='btn btn-danger' onclick='confirmDelete(" . $row['id'] . ")'>Delete</button>";

// JavaScript function to confirm delete
echo "<script>";
echo "function confirmDelete(projectId) {";
echo "    if (confirm('Are you sure you want to delete this project?')) {";
echo "        window.location.href = 'delete.php?project_id=' + projectId;";
echo "    }";
echo "}";
echo "</script>";

            echo "</div>";
            echo "</div>";
        }
    } else {
        echo '<div class="text-center">No data found for project ID: ' . $id . '</div>';
    }
}
?>

<!-- JavaScript function to confirm delete -->
<script>
    function confirmDelete(projectId) {
        if (confirm("Are you sure you want to delete this project?")) {
            window.location.href = "delete.php?project_id=" + projectId;
        }
    }
</script>

<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>

<?php
include 'footer.php';
?>
