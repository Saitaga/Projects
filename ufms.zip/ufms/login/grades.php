<?php
session_start(); // Start the session

// Include database connection
include "connection.php";
include "header.php";

// Display success message if set
if (isset($_SESSION['success_message'])) {
    echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
    unset($_SESSION['success_message']); // Clear the session variable
}

// Display error message if set
if (isset($_SESSION['error_message'])) {
    echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']); // Clear the session variable
}

// Check if a project ID is provided in the URL
if (isset($_GET['viewid'])) {
    $projectId = $_GET['viewid'];

    // Prepare the SQL statement to retrieve grading information
    $sql = "SELECT * FROM ratings WHERE project_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $projectId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Initialize variables for total score and total number of checkboxes
    $totalScore = 0;
    $totalCheckboxes = 0;

    // Initialize variables to store checkbox values
    $checkbox1 = 0;
    $checkbox2 = 0;
    $checkbox3 = 0;
    $checkbox4 = 0;
    $checkbox5 = 0;
    $checkbox6 = 0;

    // Check if grading information exists
    if ($result->num_rows > 0) {
        // Grading information found, calculate total score
        while ($row = $result->fetch_assoc()) {
            // Add checkbox values to corresponding variables
            $checkbox1 += $row['checkbox1'];
            $checkbox2 += $row['checkbox2'];
            $checkbox3 += $row['checkbox3'];
            $checkbox4 += $row['checkbox4'];
            $checkbox5 += $row['checkbox5'];
            $checkbox6 += $row['checkbox6'];

            // Calculate total score by summing up checkbox values
            $totalScore += $row['checkbox1'] + $row['checkbox2'] + $row['checkbox3'] + $row['checkbox4'] + $row['checkbox5'] + $row['checkbox6'];
            $totalCheckboxes += 6; // Increment total checkboxes by 6 for each row
        }

        // Display grading information
        echo "<div class='text-center'>";
        echo "<h2>Grading</h2>";
        echo "<p>Total Score: $totalScore </p>";
        echo "<p> Adherence to Instructions: $checkbox1</p>";
        echo "<p> Creativity: $checkbox2</p>";
        echo "<p> Content: $checkbox3</p>";
        echo "<p> Plagiarism: $checkbox4</p>";
        echo "<p> Scope: $checkbox5</p>";
        echo "<p> Objectives: $checkbox6</p>";
        
        // Calculate percentage completion
        $percentage = ($totalScore / ($totalCheckboxes * 16.66666)) * 100;
        
        // Display progress bar
        echo "<div class='progress'>";
        echo "<div class='progress-bar' role='progressbar' style='width: $percentage%;' aria-valuenow='$percentage' aria-valuemin='0' aria-valuemax='100'>$percentage%</div>";
        echo "</div>";
        echo "</div>"; // Close the text-center div
    } else {
        echo "<div class='alert alert-info text-center'>No grading information found for this project.</div>";
    }
} else {
    echo "<div class='alert alert-danger text-center'>Project ID not provided in the URL.</div>";
}

include "footer.php";
?>
