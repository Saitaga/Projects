
<?php
session_start();
// Include database connection
include 'connection.php';

// Check if the admin's course is set in the session
if (isset($_SESSION['course'])) {
    // Get the admin's course from the session
    $adminCourse = $_SESSION['course'];

    // Fetch guidelines from the database for the admin's course
    $sql = "SELECT guidelines FROM guidelines WHERE course = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $adminCourse);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there are any guidelines
    if ($result->num_rows > 0) {
        $counter = 1;
        ?>
        <div class="container mt-5">
            <h1 class="text-center">Project Guidelines</h1>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Guidelines</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><strong><?php echo $counter; ?></strong></td>
                                <td><?php echo $row['guidelines']; ?></td>
                            </tr>
                        <?php
                            $counter++;
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php
    } else {
        // If no guidelines found for the admin's course, display a message
        ?>
        <div class="container mt-5">
            <h1 class="text-center">Project Guidelines</h1>
            <div class="alert alert-warning" role="alert">
                No guidelines available for your course.
            </div>
        </div>
    <?php
    }
} else {
    // If admin's course is not set in the session, display an error message
    ?>
    <div class="container mt-5">
        <div class="alert alert-danger" role="alert">
            Error: Admin's course is not set in the session.
        </div>
    </div>
<?php
}
?>
