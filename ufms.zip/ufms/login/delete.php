<?php
include 'connection.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from project where id=$id";
    $result=mysqli_query($conn,$sql);
    if($result){
        //echo "Deleted successfully";
        header('location:table.php');
    }else{
        die(mysqli_error($conn));
    }
}

?>
<script type="text/javascript">
         <!--
            function getConfirmation(form,projectTitle){
               var retVal = confirm("Do you want to Delete the project: "+ projectTitle+" ?");
               if( retVal == true ){
                  form.submit();
               }
               else{
                 
                  return false;
               }
            }
         //-->
      </script>