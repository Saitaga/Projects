<?php
function getUserById($id, $conn) {
    // Prepare SQL query with named placeholder for user ID
    $sql = "SELECT * FROM users WHERE id = :id";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind the parameter
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); // Assuming user ID is an integer
    
    // Execute the statement
    $stmt->execute();
    
    // Fetch the user data
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if a user was found
    if ($user) {
        return $user;
    } else {
        // No user found with the given ID
        return null;
    }
}

?>