<?php  
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {



   if (isset($_POST['fname']) && isset($_POST['uname']) && isset($_POST['pass'])) {
      include "../db_conn.php";
  
      $fname = $_POST['fname'];
      $uname = $_POST['uname'];
      $password = password_hash($_POST['pass'], PASSWORD_DEFAULT); // Hash the password
      $old_pp = $_POST['old_pp'];
      $id = $_SESSION['id'];
  
      if (empty($fname)) {
          $em = "Full name is required";
          header("Location: ../edit.php?error=$em");
          exit;
      } else if (empty($uname)) {
          $em = "User name is required";
          header("Location: ../edit.php?error=$em");
          exit;
      } else if (empty($password)) {
          $em = "Password is required";
          header("Location: ../edit.php?error=$em&u=yes");
          exit;
      } else {
          // Continue with your existing logic
  
          // Update the Database with the password
          $sql = "UPDATE users 
                  SET fname=?, username=?, password=?
                  WHERE id=?";
          $stmt = $conn->prepare($sql);
          $stmt->execute([$fname, $uname, $password, $id]);
  
          header("Location: ../edit.php?success=Your account has been updated successfully");
          exit;
      }
  } else {
      header("Location: ../edit.php?error=error");
      exit;
  }
}