<?php
function getUserById($id, $conn) {
    // Prepare SQL query with placeholder for user ID
    $sql = "SELECT * FROM project WHERE id = ?";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind the parameter
    $stmt->bind_param("i", $id); // Assuming user ID is an integer
    
    // Execute the statement
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();
    
    // Check if a user was found
    if ($result->num_rows > 0) {
        // Fetch the user data
        $user = $result->fetch_assoc();
        return $user;
    } else {
        // No user found with the given ID
        return null;
    }
}


?>