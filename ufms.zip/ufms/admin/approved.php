<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="projects.css">
    <title>Projects Status</title>
</head>
<body>

    <div class="container">
        <h1>Status</h1>

        <div class="table-container">
        <div class="search-container mb-3">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by status or course">
            <button id="searchBtn" class="btn btn-primary">Search</button>
</div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Project Title</th>
                        <th>Student Name</th>
                        <th>Course</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
include 'connection.php';

// Fetch projects from the database
$sql_projects = "SELECT * FROM project";
$result_projects = $conn->query($sql_projects);

if ($result_projects->num_rows > 0) {
    while ($row_project = $result_projects->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row_project['studentName']}</td>";
        echo "<td>{$row_project['projectTitle']}</td>";
        echo "<td>{$row_project['course']}</td>";
        
        // Check the status and apply color to the text accordingly
        if ($row_project['status'] == 'Approved') {
            echo "<td><span style='color: green;'>Approved</span></td>";
        } elseif ($row_project['status'] == 'Rejected') {
            echo "<td><span style='color: red;'>Rejected</span></td>";
        } else {
            echo "<td>{$row_project['status']}</td>";
        }
        
        echo "<td><a href='view.php?viewid={$row_project['id']}' class='btn btn-primary'>View</a></td>";

        // Check if the project is approved or rejected
        if ($row_project['status'] == 'approved') {
            // If already approved, apply green marker to the approve button
            //echo "<td><a href='approve.php?project_id={$row_project['id']}' class='btn btn-success' disabled>Approve</a></td>";
            echo "<td><button class='btn btn-success' style='background-color: #99ff99;' disabled>Approve</button></td>";
            // For rejected projects, apply a red marker to the reject button
            echo "<td><button class='btn btn-danger' style='background-color: #ff9999;' disabled>Reject</button></td>";
        } elseif ($row_project['status'] == 'rejected') {
            // If already rejected, apply red marker to the reject button
            echo "<td><button class='btn btn-success' style='background-color: #99ff99;' disabled>Approve</button></td>";
            // For approved projects, apply a green marker to the approve button
            echo "<td><button class='btn btn-danger' style='background-color: #ff9999;' disabled>Reject</button></td>";
        } else {
            // If not approved or rejected, show both buttons with default colors
            echo "<td><a href='approve.php?project_id={$row_project['id']}' class='btn btn-success'>Approve</a></td>";
            echo "<td><a href='reject.php?project_id={$row_project['id']}' class='btn btn-danger'>Reject</a></td>";
       
        }
        

        echo "</tr>";
    }
} else {
    echo "No projects found.";
}
?>

                </tbody>
            </table>
        </div>
    </div>


<style>
/* styles.css */
.table-container {
    max-width: 90%; /* Adjust the width as needed */
    margin: 20px auto; /* Add some margin for spacing */
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th,
.table td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.table td {
    background-color: #fff;
}

.table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

.table tbody tr:hover {
    background-color: #f2f2f2;
}

</style>
<script>
        document.getElementById("searchBtn").addEventListener("click", function() {
            var input = document.getElementById("searchInput").value.toLowerCase();
            var rows = document.querySelectorAll("tbody tr");

            rows.forEach(function(row) {
                var status = row.children[3].textContent.toLowerCase();
                var course = row.children[2].textContent.toLowerCase();
                if (status.includes(input) || course.includes(input)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    </script>
</body>
</html>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
