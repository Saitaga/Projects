<?php
require_once 'header.php';

// Database connection
include 'connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    if (isset($_GET['viewid'])) {
        $id = $_GET['viewid'];
        $userId = $_POST['userId'];
        $checkbox1 = isset($_POST['checkbox1']) ? $_POST['checkbox1'] : 0;
        $checkbox2 = isset($_POST['checkbox2']) ? $_POST['checkbox2'] : 30;
        $checkbox3 = isset($_POST['checkbox3']) ? $_POST['checkbox3'] : 0;
        $checkbox4 = isset($_POST['checkbox4']) ? $_POST['checkbox4'] : 0;

        // Insert data into the database
        $sql = "INSERT INTO ratings (project_id, user_id, checkbox1, checkbox2, checkbox3, checkbox4) 
                VALUES ('$id', '$userId', '$checkbox1', '$checkbox2', '$checkbox3', '$checkbox4')";

        if (mysqli_query($conn, $sql)) {
            echo "Ratings inserted successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        // Close connection
        mysqli_close($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <title>Grading</title>
    <!-- <link rel="stylesheet" href="styles.css"> -->
    <style>
        /* Add your custom styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .user {
            margin-bottom: 20px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }

        .checkboxes {
            margin-bottom: 10px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        .progress-container {
            height: 20px;
            background-color: #ddd;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background-color: #4caf50;
            border-radius: 10px;
            transition: width 0.3s ease;
        }

        .progress-text {
            display: block;
            text-align: center;
            margin-top: 5px;
            font-size: 14px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Grade</h2>
        
        <div class="users">
            <div class="user" id="user1">
                <h3></h3>
                <form action="grading.php" method="POST">
                    <input type="hidden" name="userId" value="1">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <div class="checkboxes">
                        <label><input type="checkbox" name="checkbox1" value="25"> Adherence to Instructions</label><br>
                        <label><input type="checkbox" name="checkbox2" value="25"> Creativity</label><br>
                        <label><input type="checkbox" name="checkbox3" value="25"> Content</label><br>
                        <label><input type="checkbox" name="checkbox4" value="25"> Plagiarism</label><br>
                    </div>
                    <input type="submit" value="Submit">
                </form>

                <div class="progress-container">
                    <div class="progress-bar user1" id="progress-bar-user1"></div>
                    <span class="progress-text" id="user1-progress-text">0%</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Your JavaScript code here
        
    const users = document.querySelectorAll('.user');

    users.forEach(user => {
        const checkboxes = user.querySelectorAll('input[type="checkbox"]');
        const progressBar = user.querySelector('.progress-bar');
        const progressText = user.querySelector('.progress-text');

        let totalCheckboxes = checkboxes.length;
        let progress = 0;

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateProgress);
        });

        function updateProgress() {
            let checkedCheckboxes = user.querySelectorAll('input[type="checkbox"]:checked').length;
            progress = (checkedCheckboxes / totalCheckboxes) * 100;
            progressBar.style.width = progress + '%';
            progressText.textContent = Math.round(progress) + '%';
        }

        // Initial progress update
        updateProgress();
    });
    </script>
</body>
</html>

<?php require_once 'footer.php'; ?>
