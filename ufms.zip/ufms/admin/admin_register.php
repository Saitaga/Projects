<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 50px;
            margin-bottom: 20px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label, input, select {
            display: block;
            margin-bottom: 15px;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: calc(100% - 12px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"],
        .btn-success {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
        }

        .btn-success {
            background-color: #28a745;
            color: #fff;
        }

        .btn-secondary {
            margin-top: 10px;
            width: 100%;
        }
    </style>
</head>
<body>
    <h2>Admin Registration</h2>
    <form action="register_process.php" method="POST">
        <label for="admin_id">Admin ID:</label>
        <input type="text" id="admin_id" name="admin_id"><br>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="pfNo">PF Number (Format: ABxxxxx or XYxxxxx):</label>
        <input type="text" id="pfNo" name="pfNo" pattern="[A-Za-z]{2}\d{5}" title="Format: Two alphabets followed by 5 digits" required>

        <label for="course">Course:</label>
        <select id="course" name="course" required>
            <option value="">Select Course</option>
            <option value="Information Technology">Information Technology</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Business and Information Technology">Business and Information Technology</option>
            <option value="Business">Business</option>
            <option value="Education">Education</option>
            <option value="Health Sciences">Health Sciences</option>
        </select><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <input type="submit" value="Register">
        <a href="admin_login.php" class="btn btn-success">Login</a>
        <button onclick="goBack()" class="btn btn-secondary">Back</button>
    </form>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
