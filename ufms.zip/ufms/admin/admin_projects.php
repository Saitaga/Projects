
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Projects Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <br><br>
    <div class="d-flex justify-content-center">
    <img src="LOGO2.png" alt="Logo" class="img-fluid" style="max-width: 100px; height: auto;">
</div>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .table-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .table td {
            background-color: #fff;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tbody tr:hover {
            background-color: #f2f2f2;
        }

        .btn-approve {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-reject {
            background-color: #dc3545;
            border-color: #dc3545;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <h1 class="text-center"></h1>
        <div class="search-container mb-3">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by status or name">
            <br>
            <button id="searchBtn" class="btn btn-primary">Search</button>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Project Title</th>
                        <th>Student Name</th>
                        <th>Course</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php
                    include 'connection.php';

                    // Check if admin is logged in
                    session_start();
                    if (!isset($_SESSION['admin_id'])) {
                        header("Location: admin_login.php");
                        exit();
                    }
                    
                      


                    // Fetch admin's course
                    $admin_id = $_SESSION['admin_id'];
                    $sql_admin = "SELECT course FROM admins WHERE admin_id=?";
                    $stmt_admin = $conn->prepare($sql_admin);
                    $stmt_admin->bind_param("i", $admin_id);
                    $stmt_admin->execute();
                    $result_admin = $stmt_admin->get_result();
                    $row_admin = $result_admin->fetch_assoc();
                    $course = $row_admin['course'];

                    // Fetch projects based on admin's course
                    $sql_projects = "SELECT * FROM project WHERE course=?";
                    $stmt_projects = $conn->prepare($sql_projects);
                    $stmt_projects->bind_param("s", $course);
                    $stmt_projects->execute();
                    $result_projects = $stmt_projects->get_result();

                    if ($result_projects->num_rows > 0) {
                        while ($row_project = $result_projects->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row_project['projectTitle'] . "</td>";
                            echo "<td>" . $row_project['studentName'] . "</td>";
                            echo "<td>" . $row_project['course'] . "</td>";

                            if ($row_project['status'] == 'Approved') {
                                echo "<td><span style='color: green;'>Approved</span></td>";
                            } elseif ($row_project['status'] == 'Rejected') {
                                echo "<td><span style='color: red;'>Rejected</span></td>";
                            } else {
                                echo "<td>{$row_project['status']}</td>";
                            }
                            echo "<td class='text-center'>";
                            echo "<div class='btn-group' role='group'>";
                            echo "<form action='approve.php' method='POST' style='display: inline; margin-right: 15px;'>";
                            echo "<input type='hidden' name='project_id' value='" . $row_project['id'] . "'>";
                            echo "<button type='submit' class='btn btn-success btn-approve' name='approve'>Approve</button>";
                            echo "</form>";
                            echo "<form action='reject.php' method='POST' style='display: inline; margin-right: 15px;'>";
                            echo "<input type='hidden' name='project_id' value='" . $row_project['id'] . "'>";
                            echo "<button type='submit' class='btn btn-danger btn-reject' name='reject'>Reject</button>";
                            echo "</form>";
                            if ($row_project['course'] === $course) {
                           }
                            echo "<button class='btn btn-primary btn-view'><a href='adminView.php?viewid=" . $row_project['id'] . "' class='text-light'>View</a></button>";
                            echo "</div>";
                            echo "</td>";
                            
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No projects found.</td></tr>";
                    }

                    // Close statements and connection
                    $stmt_admin->close();
                    $stmt_projects->close();
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    document.getElementById("searchBtn").addEventListener("click", function() {
        var input = document.getElementById("searchInput").value.trim().toLowerCase();
        var rows = document.querySelectorAll("tbody tr");

        rows.forEach(function(row) {
            var status = row.children[3].textContent.toLowerCase();
            var studentName = row.children[1].textContent.toLowerCase();
            if (status.includes(input) || studentName.includes(input)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
</script>

</body>
</html>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
