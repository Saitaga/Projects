<?php
// Connect to the database
$host = 'localhost';
$db   = 'auth_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $opt);

// Check if form is submitted
if (isset($_POST['approve'])) {
    // Get form data
    $username = $_POST['username'];
    $fname = $_POST['fname'];
    $pass = $_POST['pass'];

    // Prepare and execute the SQL statement
    $sql = "INSERT INTO users (username, fname, pass) VALUES (:username, :fname, :pass)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':username' => $username, ':fname' => $fname, ':pass' => $pass]);

    // Redirect to the user list page
    header('Location: home.php');
    exit;
}

// Get the user data from the database
$sql = "SELECT * FROM users WHERE approved = 0";
$stmt = $pdo->query($sql);
$users = $stmt->fetchAll();
?>

<?php
session_start();
if (!isset($_SESSION["username"])) {
    // User is not logged in, redirect to login page
    header("Location: index.php");
    exit;
}

$username = $_GET['username'];

// Update the user's status in the database
$conn = mysqli_connect("localhost", "root", "", "phplogin");
$sql = "UPDATE accounts SET approved = 1 WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->close();
$conn->close();

// Return a success message
echo json_encode(array('success' => true)); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Registration Approval</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
            
</head>
<body>
    <h1>User Registration Approval</h1>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>First Name</th>
            <th>Approve</th>
        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['fname']) ?></td>
                <td>
                    <form method="post" action="">
                        <input type="hidden" name="username" value="<?= htmlspecialchars($user['username']) ?>">
                        <input type="hidden" name="fname" value="<?= htmlspecialchars($user['fname']) ?>">
                        <input type="hidden" name="pass" value="<?= htmlspecialchars($user['pass']) ?>">
                        <input type="submit" name="approve" value="Approve">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>

