<?php
session_start(); // Start the session

include "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the project ID and feedback text are provided
    if (isset($_POST['id']) && isset($_POST['feedback'])) {
        // Retrieve project ID and feedback text from the form
        $id = $_POST['id'];
        $feedback = $_POST['feedback'];

        // Prepare the SQL statement to insert or update feedback into the database
        $stmt = $conn->prepare("UPDATE project SET feedback = ? WHERE id = ?");
        $stmt->bind_param("si", $feedback, $id);

        // Execute the statement
        if ($stmt->execute()) {
            // Feedback inserted or updated successfully
            $_SESSION['success_message'] = "Feedback submitted successfully!";
            header("Location: adminView.php");
        } else {
            // Error occurred while inserting or updating feedback
            $_SESSION['error_message'] = "Error: Unable to submit feedback.";
        }
    } else {
        // Project ID or feedback text is missing
        $_SESSION['error_message'] = "Error: Project ID or feedback is missing.";
    }
} else {
    // Invalid request method
    $_SESSION['error_message'] = "Error: Invalid request method.";
}

// Redirect back to the adminView.php page
header("Location: adminView.php");
exit();
?>
