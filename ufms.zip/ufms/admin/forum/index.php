<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <title>Forum</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
<header class="d-flex justify-content-between align-items-center">
    <div>
        <h1>Forum</h1>
        <nav>
            <ul>
                 <li><a href="post_form.html">Post</a></li>
                <!--<li><a href="post_form.html">Post</a></li>
                <li><a href="register.php">Register</a></li> -->
                <!-- <li><a href="../message/sendMessage.php">Chat</a></li> -->
            </ul>
        </nav>
    </div>
    <img src="LOGO2.png" alt="Logo" class="img-fluid" style="max-width: 100px; height: auto;">
</header>


    <main>
        <section id="categories">
            <h2>Categories</h2>
            <ul>
                <?php
                // Fetch categories from the database and populate the list
                require_once('db_connection.php');

                $sql_categories = "SELECT * FROM categories";
                $result_categories = $conn->query($sql_categories);

                if ($result_categories->num_rows > 0) {
                    while($row_category = $result_categories->fetch_assoc()) {
                        echo "<li><a href='#'>" . $row_category['category_name'] . "</a></li>";
                    }
                } else {
                    echo "<li>No categories found.</li>";
                }

                
                ?>
            </ul>
        </section>

        <section id="posts">
            <h2>Recent Posts</h2>
            <?php
            // Fetch recent posts from the database and populate the section
            require_once('db_connection.php');

            $sql_posts = "SELECT * FROM posts ORDER BY course, post_date DESC LIMIT 5";
            $result_posts = $conn->query($sql_posts);

                                $current_course = "";
                    while($row_post = $result_posts->fetch_assoc()) {
                        if ($row_post['course'] != $current_course) {
                            echo "<h3>" . $row_post['course'] . "</h3>"; // Display course name as heading
                            $current_course = $row_post['course'];
                        }
                        // Display post details within the corresponding course section
                        echo "<article>";
                        // Post details here...
                        echo "</article>";
                    


            if ($result_posts->num_rows > 0) {
                while($row_post = $result_posts->fetch_assoc()) {
                    echo "<article>";
                    echo "<h3><a href='#'>" . $row_post['title'] . "</a></h3>";
                    echo "<p>Posted by <strong>" . $row_post['username'] . "</strong>  <em>" . $row_post['category'] . "</em>  <time>" . $row_post['post_date'] . "</time></p>";
                     echo "<p>Created at <strong><em>" . $row_post['created_at'] . "</strong> </em>";
                    
                    echo "<p>" . substr($row_post['content'], 0, 100) . "...</p>"; // Display a preview of post content
                    echo "<a href='post_detail.php?id=" . $row_post['id'] . "'>Read more</a>"; // Link to the post detail page
       
                    echo "</article>";
                }
            } else {
                echo "<p>No posts found.</p>";
            }
        }
            $conn->close();
            ?>

<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>

        </section>
    </main>

    <footer>
        <p>&copy; 2024 Forum. All rights reserved.</p>
    </footer>
</body>
</html>

