function sendMessage() {
    var messageInput = document.getElementById("message-input");
    var message = messageInput.value;
    if (message.trim() !== "") {
        // Send message to server
        fetch('send_message.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayMessage(message);
                messageInput.value = "";
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}

function displayMessage(message) {
    var chatOutput = document.getElementById("chat-output");
    var newMessage = document.createElement("p");
    newMessage.textContent = message;
    chatOutput.appendChild(newMessage);
    chatOutput.scrollTop = chatOutput.scrollHeight;
}

// Fetch and display messages from server
function fetchMessages() {
    fetch('get_messages.php')
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            data.messages.forEach(message => {
                displayMessage(message);
            });
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Load messages when the page loads
window.onload = function() {
    fetchMessages();
};
