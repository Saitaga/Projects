<?php

// Include the database connection
include "db_connection.php";

// Prepare and execute the SQL SELECT statement
$sql = "SELECT message, sender FROM messages ORDER BY created_at ASC";
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Fetch rows and store them in an array
    $messages = array();
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    // Respond with success and the messages array
    echo json_encode(['success' => true, 'messages' => $messages]);
} else {
    // Respond with an error message
    echo json_encode(['success' => false, 'message' => 'No messages found']);
}

// Close the database connection
$conn->close();

?>
