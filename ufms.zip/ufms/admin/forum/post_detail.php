<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Post Detail</title>


            <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .post {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .post h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 10px;
        }

        .post p {
            font-size: 16px;
            line-height: 1.6;
            color: #555;
        }

        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
        }

        .back-link a {
            color: #007bff;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container text-center">
    <img src="LOGO2.png" alt="Logo" class="img-fluid" style="max-width: 150px; height: auto;">
</div>
    <div class="container">
        <?php
       require_once('db_connection.php');

        // Retrieve the post ID from the URL
        if (isset($_GET['id'])) {
            $post_id = $_GET['id'];

            // Fetch the post content from the database
            $sql = "SELECT title, content FROM posts WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $post_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $row_post= $result->fetch_assoc();
                ?>
                <div class="post">
                    <h2><?php echo $row_post['title']; ?></h2>
                    <p><?php echo $row_post['content']; ?></p>
                </div>
                <?php
            } else {
                echo "<p>Post not found.</p>";
            }
        } else {
            echo "<p>Post ID not specified.</p>";
        }
        ?>
        <div class="back-link">
            <a href="index.php">&larr; Back to Posts</a>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Forum. All rights reserved.</p>
    </footer>
</body>
</html>

