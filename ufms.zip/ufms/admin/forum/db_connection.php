<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "forum";

// Attempt to establish a connection to the database
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Check if the connection was successful
if ($conn->connect_errno) {
    die("Failed to connect to MySQL: " . $conn->connect_error);
}

// Optionally set the character set to UTF-8
if (!$conn->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $conn->error);
    exit();
}

// The connection is now established and ready to use
