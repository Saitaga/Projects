<?php

// Include the database connection
include "db_connection.php";

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the message and sender from the request body
    $data = json_decode(file_get_contents("php://input"), true);
    $message = $data['message'];
    $sender = $data['sender'];

    // Prepare and execute the SQL INSERT statement
    $sql = "INSERT INTO messages (message, sender) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $message, $sender);
    $stmt->execute();

    // Check if the insertion was successful
    if ($stmt->affected_rows > 0) {
        // Respond with success
        echo json_encode(['success' => true]);
    } else {
        // Respond with an error message
        echo json_encode(['success' => false, 'message' => 'Failed to send message']);
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();

?>
