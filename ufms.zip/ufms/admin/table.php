<?php
session_start();
include 'header.php';
include 'connection.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Initialize variables
$search = "";

// Check if the search form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $search = $_POST['search'];
    // Prepare the SQL statement to search for projects
    $sql = "SELECT * FROM project WHERE projectTitle LIKE '%$search%' OR studentName LIKE '%$search%' OR course LIKE '%$search%'";
} else {
    // If search form is not submitted, retrieve all projects
    $sql = "SELECT * FROM project ORDER BY course";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="projects.css">
    <script src="scripts.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        table {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1 class="text-center mb-5">Project List</h1>
    <hr>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input class="form-control me-2" type="search" name="search" value="<?php echo $search; ?>" placeholder="Search by Course, Student Name, or Project Title" aria-label="Search">
                <button id="searchBtn" class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </nav>

    <table class="table ">
        <thead>
            <tr>
                <th scope="col">Project Title</th>
                <th scope="col">Student Name</th>
                <th scope="col">Email</th>
                <th scope="col">Course</th>
                <th scope="col">Status</th>
                <th scope="col">File</th>
                <th scope="col">Action</th>
            </tr>
        </thead>

        <tbody>
        <?php  
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $projectTitle = $row['projectTitle'];
        $studentName = $row['studentName'];
        $studentEmail = $row['studentEmail'];
        $course = $row['course'];
        $status = $row['status'];
        $file = $row['file'];

        // Set color based on status
        $statusColor = ($status == 'Approved') ? 'text-success' : (($status == 'Rejected') ? 'text-danger' : '');

        echo '<tr>
            <td>' . $projectTitle . '</td>
            <td>' . $studentName . '</td>
            <td>' . $studentEmail . '</td>
            <td>' . $course . '</td>
            <td class="' . $statusColor . '">' . $status . '</td>
            <td><a href="uploads/' . $file . '" download>' . $file . '</a></td>
            <td>
                <button class="btn btn-primary"><a href="view.php?viewid=' . $row['id'] . '" class="text-light">View</a></button>
            </td>
        </tr>';
    }
} else {
    echo '<tr><td colspan="7">No projects found.</td></tr>';
}
?>
        </tbody>
    </table>
</body>
</html>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
