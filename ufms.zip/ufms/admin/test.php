<?php
// Database connection
include 'connection.php';

// Query to retrieve ratings data
$sql = "SELECT * FROM ratings";

// Perform the query
$result = mysqli_query($conn, $sql);

// Check if there are any results
if (mysqli_num_rows($result) > 0) {
    // Output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        echo "User ID: " . $row["user_id"] . "<br>";
        echo "Adherence to Instruction: " . $row["checkbox1"] . "<br>";
        echo "Creativity: " . $row["checkbox2"] . "<br>";
        echo "Content: " . $row["checkbox3"] . "<br>";
        echo "Plagiarism: " . $row["checkbox4"] . "<br>";
        echo "<hr>";
    }
} else {
    echo "No ratings found";
}

// Close connection
mysqli_close($conn);
?>
