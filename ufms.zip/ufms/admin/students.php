<?php
include 'connection.php';

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'header.php';

// Fetch admin's course
$admin_id = $_SESSION['admin_id'];
$sql_admin = "SELECT course FROM admins WHERE admin_id=?";
$stmt_admin = $conn->prepare($sql_admin);
$stmt_admin->bind_param("i", $admin_id);
$stmt_admin->execute();
$result_admin = $stmt_admin->get_result();
$row_admin = $result_admin->fetch_assoc();
$course = $row_admin['course'];

// Fetch students based on admin's course
$sql_students = "SELECT * FROM users WHERE course=?";
$stmt_students = $conn->prepare($sql_students);
$stmt_students->bind_param("s", $course);
$stmt_students->execute();
$result_students = $stmt_students->get_result();


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        /* Custom styles for the table */
        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .table th,
        .table td {
            padding: 8px;
            border: 1px solid #dee2e6;
        }

        .table th {
            background-color: #f8f9fa;
            color: #212529;
            font-weight: bold;
            text-align: left;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, .05);
        }
    
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Registered Students</h1>
        <div class="mb-3">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by name or reg no.">
        </div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Registration No</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result_students->num_rows > 0) {
                        $count = 1;
                        while ($row_student = $result_students->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>{$count}</td>";
                            echo "<td>{$row_student['fname']}</td>";
                            echo "<td>{$row_student['course']}</td>";
                            echo "<td>{$row_student['username']}</td>";
                            echo "</tr>";
                            $count++;
                        }
                    } else {
                        echo "<tr><td colspan='4'>No students found for the course '{$course}'</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        // Add event listener to the search input field
        document.getElementById('searchInput').addEventListener('input', function() {
            var searchValue = this.value.trim().toLowerCase();
            var rows = document.querySelectorAll('tbody tr');

            rows.forEach(function(row) {
                var name = row.children[1].textContent.trim().toLowerCase();
                var username = row.children[3].textContent.trim().toLowerCase();

                if (name.includes(searchValue) || username.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    </script>
</body>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>
</html>
