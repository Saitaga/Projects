<?php
session_start();
// Database connection
include 'connection.php';

// Retrieve data from form
if (isset($_POST["submit"])) {
    $pfNo = $_POST['pfNo'];
    $password = $_POST['password'];

    // Fetch hashed password from the database based on pfNo
    $sql = "SELECT * FROM admins WHERE pfNo = '$pfNo'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);

    if ($user) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['admin_id'] = $user['admin_id'];
            header("Location: home.php");
            exit();
        } else {
            echo "<script>alert('Password doesn\'t match')</script>";
        }
    } else {
        echo "<script>alert('User does not exist')</script>";
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        form {
            max-width: 400px;
            margin: 0 auto; /* Center the form horizontally */
            margin-top: 50px; /* Add some top margin for better spacing */
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h5, h6 {
            text-align: center;
            margin-bottom: 20px;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"], input[type="password"] {
            width: calc(100% - 12px);
            padding: 6px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"],
        .btn-success,
        .btn-secondary {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
        }

        .btn-success {
            background-color: #28a745;
            color: #fff;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>
<body>
    <form action="admin_login.php" method="POST">
        <h5 class="display-6">Admin</h5>
        <h6 class="display-8">LOGIN</h6>
        <label for="pfNo">PF no:</label>
        <input type="text" id="pfNo" name="pfNo" required>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        
        <input type="submit" name="submit" value="Login">
        <a href="admin_register.php" class="btn btn-success">Register</a>
    <br>
    <br>
        <a href="../login/login.php" class="btn btn-secondary">User</a>
    </form>
</body>
</html>

