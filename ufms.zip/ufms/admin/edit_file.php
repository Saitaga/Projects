<?php
if (isset($_GET['filename'])) {
    $filename = $_GET['filename'];

    // Load the file content
    $filePath = "uploads/$filename";
    $fileContent = file_get_contents($filePath);
    if ($fileContent !== false) {
        // Display a form for editing the file content
?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Edit File: <?php echo $filename; ?></title>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        </head>
        <body>
            <div class="container">
                <h2>Edit File: <?php echo $filename; ?></h2>

                <form action="save_file.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="project_id" value="<?php echo $id;?>">
                <input type="file" name="new_file">
                <button type="submit" name="submit">Upload File</button>

            
                        <textarea class="form-control" name="content" rows="10"><?php echo htmlspecialchars($fileContent); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </body>
        </html>
<?php
    } else {
        echo "Error: Unable to load file.";
    }
} else {
    echo "Error: File not specified.";
}
?>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>