<?php
session_start();

// Include database connection
include 'connection.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page
    header("Location: admin_login.php");
    exit(); // Stop further execution
}

// Include header and footer
include 'header.php';
//include 'footer.php';

// Fetch admin details from the database
$admin_id = $_SESSION['admin_id'];
$sql = "SELECT * FROM admins WHERE admin_id='$admin_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Profile</title>
<link rel="stylesheet" href="styles.css">
<style>
    .profile-card {
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
        margin: 20px auto;
        max-width: 400px;
    }
    .profile-card h2 {
        margin-top: 0;
        font-size: 24px;
        color: #333;
    }
    .profile-card p {
        margin: 10px 0;
        color: #666;
    }
</style>
</head>
<body>
<div class="container">
    <?php
    // Fetch admin details from the database
    $admin_id = $_SESSION['admin_id'];
    $sql = "SELECT * FROM admins WHERE admin_id='$admin_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>
        <h1>Welcome, <?php echo $row['pfNo']; ?>!</h1>
        <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="profile-card">
                <h2><?php echo $row['name']; ?></h2>
                <p><strong>Admin ID:</strong> <?php echo $row['admin_id']; ?></p>
                <p><strong>Name:</strong> <?php echo $row['name'];?></p>
                <p><strong>PF Number:</strong> <?php echo $row['pfNo']; ?></p>
                <p><strong>Supervisor:</strong> <?php echo $row['course']; ?></p>
                <?php if (isset($row['last_login'])) { ?>
                <p><strong>Last Login:</strong> <?php echo $row['last_login']; ?></p>
                <?php } else { ?>
                <p><strong>Last Login:</strong> Not available</p>
                <?php } ?>
                <p><strong>Current Date:</strong> <?php echo date("Y-m-d"); ?></p>
                <br>
                <div class="text-center">
                    <a href="admin_projects.php" class="btn btn-secondary">
                        My Projects
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

        <?php
    } else {
        echo "Admin details not found";
    }
    ?>
</div>
</body>
</html>


<?php
} else {
    echo "Admin details not found";
}
$conn->close();

include 'footer.php';
?>

