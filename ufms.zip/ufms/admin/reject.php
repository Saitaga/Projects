<?php
session_start();
include 'connection.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_POST['reject']) && isset($_POST['project_id'])) {
    $project_id = $_POST['project_id'];
    
    // Update project status to 'rejected' in the database
    $sql_reject = "UPDATE project SET status = 'Rejected' WHERE id = ?";
    $stmt_reject = $conn->prepare($sql_reject);
    $stmt_reject->bind_param("i", $project_id);

    if ($stmt_reject->execute()) {
        // Redirect back to the page with a success message
        header("Location: admin_projects.php?status=Rejected");
        exit();
    } else {
        // Redirect back to the page with an error message
        header("Location: admin_projects.php?error=update_failed");
        exit();
    }
} else {
    // If the form is not submitted properly, redirect back to the page
    header("Location: admin_projects.php");
    exit();
}
?>
