<?php
session_start();

// Include database connection
require_once "connection.php";
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check admin credentials
    $sql = "SELECT id FROM admins WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if (isset($username['username'])) {
        // Access the username key
        $username = $username['username'];
    } else {
        // Handle the case where the key doesn't exist
        $username = null; // Or any other default value
    }
    

    if ($result->num_rows == 1) {
        // Admin authenticated
        $row = $result->fetch_assoc();
        $_SESSION['admin_id'] = $row['id'];
        header("Location: admin_page.php");
        exit();
    } else {
        // Invalid credentials
        echo "Invalid username or password.";
    }
} else {
    header("Location: admin_login.php"); // Redirect if accessed directly
    exit();
}
?>
