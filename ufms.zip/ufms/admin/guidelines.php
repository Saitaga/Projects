<?php
session_start();
include 'connection.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Retrieve admin's course from the database
$admin_id = $_SESSION['admin_id'];
$sql = "SELECT course FROM admins WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Admin course found, store it in session
    $row = $result->fetch_assoc();
    $_SESSION['course'] = $row['course'];
} else {
    // Admin course not found, handle accordingly
    $_SESSION['course'] = ""; // Set default value or handle error
}

// Check if the admin's course is set in the session
if (isset($_SESSION['course'])) {
    // Get the admin's course from the session
    $course = $_SESSION['course'];

    // Check if form is submitted
    if (isset($_POST['submit'])) {
        // Check if a file is selected
        if ($_FILES['guidelinesFile']['error'] === UPLOAD_ERR_OK) {
            // Get file details
            $fileName = $_FILES['guidelinesFile']['name'];
            $fileTmpName = $_FILES['guidelinesFile']['tmp_name'];
            $fileType = $_FILES['guidelinesFile']['type'];
            $fileSize = $_FILES['guidelinesFile']['size'];

            // Define upload directory
            $uploadDir = 'uploads/';
            
            // Generate unique file name
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $uniqueFileName = uniqid('guidelines_') . '.' . $fileExtension;

            // Upload file to server
            $uploadPath = $uploadDir . $uniqueFileName;
            if (move_uploaded_file($fileTmpName, $uploadPath)) {
                // File upload successful, insert into database
                $sql = "INSERT INTO guidelines (course, guidelines_file) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $course, $uploadPath);
                if ($stmt->execute()) {
                    header("Location: guidelines.php?success=File uploaded successfully.");
                    exit();
                } else {
                    header("Location: guidelines.php?error=Error inserting file into database.");
                    exit();
                }
            } else {
                header("Location: guidelines.php?error=Error uploading file.");
                exit();
            }
        } else {
            header("Location: guidelines.php?error=Please select a file.");
            exit();
        }
    } else {
        header("Location: guidelines.php");
        exit();
    }
} else {
    // If admin's course is not set in the session, display an error message
    header("Location: guidelines.php?error=Admin's course is not set in the session.");
    exit();
}
?>
