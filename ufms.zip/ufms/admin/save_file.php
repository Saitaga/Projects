<?php
// Include the necessary files and establish database connection
include "connection.php";
include "header.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if (isset($_POST['project_id']) && isset($_FILES['new_file'])) {
        $project_id = $_POST['project_id'];

        // Retrieve file information
        $file_name = $_FILES['new_file']['name'];
        $file_tmp = $_FILES['new_file']['tmp_name'];

        // Check if file was uploaded successfully
        if (move_uploaded_file($file_tmp, "uploads/" . $file_name)) {
            // Update file information in the database
            $sql_update = "UPDATE project SET file = ? WHERE id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param("si", $file_name, $project_id);

            if ($stmt_update->execute()) {
                // File information updated successfully
                echo "<div style='text-align: center;'>File updated successfully.</div>";
            } else {
                // Error updating file information
                echo "<div style='text-align: center;'>Error updating file information.</div>";
            }
        } else {
            // Error moving uploaded file
            echo "<div style='text-align: center;'>Error uploading file.</div>";
        }
    } else {
        // Required fields not set
        echo "<div style='text-align: center;'>Required fields are not set.</div>";
    }
} else {
    // Redirect to the home page if accessed directly
    header("Location: index.php");
    exit();
}

include 'footer.php';
?>
