<?php
if (isset($_GET['filename'])) {
    $filename = $_GET['filename'];

    // Check if the file exists
    $filePath = "uploads/$filename";
    if (file_exists($filePath)) {
        // Set headers for file download
        header("Content-Type: application/octet-stream");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        readfile($filePath);
        exit();
    } else {
        echo "Error: File not found.";
    }
} else {
    echo "Error: File not specified.";
}
?>
