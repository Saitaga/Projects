<?php
session_start(); // Start the session

include "connection.php";
include "header.php";

// Display success message if set
if (isset($_SESSION['success_message'])) {
    echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
    unset($_SESSION['success_message']); // Clear the session variable
}

// Display error message if set
if (isset($_SESSION['error_message'])) {
    echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']); // Clear the session variable
}
?>

<div class="container">
    <?php
    // Check if a project ID is provided in the URL
    if (isset($_GET['viewid'])) {
        $id = $_GET['viewid'];

        // Prepare the SQL statement with a placeholder
        $sql = "SELECT * FROM project WHERE id = ?";
        $stmt = $conn->prepare($sql);

        // Bind the parameter
        $stmt->bind_param("i", $id);

        // Execute the statement
        $stmt->execute();

        // Get the result
        $result = $stmt->get_result();

        // Check if the project exists
        if ($result->num_rows > 0) {
            // Project found, display its details
            while ($row = $result->fetch_assoc()) {
    ?>
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <h2 class="text-center mb-4">Project Details</h2>
                        <div class="card">
                            <div class="card-body">
                                <p><strong>Project Title:</strong> <?php echo $row['projectTitle']; ?></p>
                                <p><strong>Student Name:</strong> <?php echo $row['studentName']; ?></p>
                                <p><strong>Student Email:</strong> <?php echo $row['studentEmail']; ?></p>
                                <p><strong>Course:</strong> <?php echo $row['course']; ?></p>
                                <p><strong>Status:</strong><?php     
                                if ($row['status'] == 'Approved') {
                                        echo "<td><span style='color: green;'>Approved</span></td>";
                                    } elseif ($row['status'] == 'Rejected') {
                                        echo "<td><span style='color: red;'>Rejected</span></td>";
                                    } else {
                                        echo "<td>{$row['status']}</td>";
                                    }
                                    ?></p>
                                <p><strong>Description:</strong></p>
                                <p><?php echo $row['description']; ?></p>

                                <!-- Display the files with download links -->
                                <p><strong>Files:</strong></p>
                                <?php
                                $files = explode(",", $row['file']); // Assuming files are stored as comma-separated values
                                foreach ($files as $file) {
                                ?>
                                    <p><a href='uploads/<?php echo $file; ?>' download><?php echo $file; ?></a> - <a href='edit_file.php?filename=<?php echo $file; ?>'>Edit</a> | <a href='download_file.php?filename=<?php echo $file; ?>'>Download</a></p>
                                <?php
                                }
                                ?>
                            </div>
                        </div>

                        <!-- Feedback form -->
                        <div class="card mt-4">
                            <div class="card-body">
                                <h2 class="text-center mb-4">Feedback</h2>
                                <form id="feedback" action="submit_feedback.php" method="post">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                    <div class="form-group">
                                        <label for="feedback">Feedback:</label>
                                        <textarea class="form-control" name="feedback" id="feedback" rows="5" placeholder="Enter your feedback"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-success btn-block">Submit Feedback</button>
                                </form>
                            </div>
                        </div>

                        <!-- Grading component -->
                        <div class="card mt-4">
                            <div class="card-body">
                                <h2 class="text-center mb-4">Grading</h2>
                                <form action="rate_project.php" method="POST">
                                    <input type="hidden" name="userId" value="<?php echo $_SESSION['admin_id']; ?>">
                                    <input type="hidden" name="projectId" value="<?php echo $id; ?>">
                                    <div class="checkboxes">
                                        <label><input type="checkbox" name="checkbox1" value="20"> Adherence to Instructions</label><br>
                                        <label><input type="checkbox" name="checkbox2" value="15"> Creativity</label><br>
                                        <label><input type="checkbox" name="checkbox3" value="15"> Content</label><br>
                                        <label><input type="checkbox" name="checkbox4" value="10"> Plagiarism</label><br>
                                        <label><input type="checkbox" name="checkbox5" value="20"> Scope</label><br>
                                        <label><input type="checkbox" name="checkbox6" value="20"> Objectives</label><br>
                                    </div>
                                    <input type="submit" value="Submit Grades" class="btn btn-primary btn-block">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    <?php
            }
        } else {
            echo '<div class="text-center">No data found for project ID: ' . $id . '</div>';
        }
    }
    ?>
</div>

<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>

<?php
include 'footer.php';
?>
