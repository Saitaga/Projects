<?php
include 'connection.php';

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if (isset($_POST['project_id']) && isset($_FILES['new_file'])) {
        $project_id = $_POST['project_id'];
        $new_file = $_FILES['new_file'];

        // Validate project ID (you may add more validation here)
        if (!is_numeric($project_id)) {
            echo "Invalid project ID.";
            exit;
        }

        // Process the uploaded file
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($new_file["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "File already exists.";
            $uploadOk = 0;
        }

        // Check file size (adjust as needed)
        if ($new_file["size"] > 5000000) {
            echo "File is too large.";
            $uploadOk = 0;
        }

        // Allow only certain file formats (you can modify this list)
     // Allow only certain file formats (add PDF and DOCX)
if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "pdf" && $imageFileType != "docx") {
    echo "Only JPG, JPEG, PNG, GIF, PDF, and DOCX files are allowed.";
    $uploadOk = 0;
}

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "File was not uploaded.";
        } else {
            // If everything is ok, try to upload file
            if (move_uploaded_file($new_file["tmp_name"], $target_file)) {
                // Update the file name in the database
                $sql = "UPDATE project SET file = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $new_file["name"], $project_id);
                if ($stmt->execute()) {
                    echo "File " . htmlspecialchars(basename($new_file["name"])) . " has been updated.";
                } else {
                    echo "Error updating file in the database.";
                }
                $stmt->close();
            } else {
                echo "Error uploading file.";
            }
        }
    } else {
        echo "Required fields are not set.";
    }
}
?>
