<?php
// Database connection
// include 'db_conn.php';

// // Retrieve data from form
// $pfNo = $_POST['pfNo'];
// $password = $_POST['password']; // Assuming you have a password field in your form

// // Fetch hashed password from the database based on pfNo
// $sql = "SELECT password FROM admins WHERE pfNo = '$pfNo'";
// $result = $conn->query($sql);

// echo $pfNo;
// if ($result->num_rows > 0) {
//     $row = $result->fetch_assoc();
//     $hashedPassword = $row['password'];

//     // Verify the password
//     // if (password_verify($password, $hashedPassword)) {
//     //     // Password is correct, login successful
//     //     echo "Login successful";
//         // Proceed with your login logic here, like setting sessions or redirecting to a dashboard
//     if (password_verify($password, $hashedPassword)) {
//         // Authentication successful
//         $_SESSION['pfNo'] = $row['pfNo'];
//         header("Location: home.php");
//         exit(); // Stop further execution
//     }          

        
//     } else {
//         // Password is incorrect
//         echo "Incorrect password";
//         echo "Entered Password: " . $password . "<br>";
//         echo "Hashed Password from DB: " . $row['password'] . "<br>";
//     }

// //}
// //  else {
// //     // No user found with the provided pfNo
// //     echo "User not found";
// // }

// $conn->close();
?>
