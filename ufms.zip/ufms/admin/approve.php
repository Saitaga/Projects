<?php
session_start();
include 'connection.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_POST['approve']) && isset($_POST['project_id'])) {
    $project_id = $_POST['project_id'];
    
    // Update project status to 'approved' in the database
    $sql_approve = "UPDATE project SET status = 'Approved' WHERE id = ?";
    $stmt_approve = $conn->prepare($sql_approve);
    $stmt_approve->bind_param("i", $project_id);

    if ($stmt_approve->execute()) {
        // Redirect back to the page with a success message
        header("Location: admin_projects.php?status=Approved");
        exit();
    } else {
        // Redirect back to the page with an error message
        header("Location: admin_projects.php?error=update_failed");
        exit();
    }
} else {
    // If the form is not submitted properly, redirect back to the page
    header("Location: admin_projects.php");
    exit();
}
?>
