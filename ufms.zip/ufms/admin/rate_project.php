<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit(); // Stop script execution
}

include "connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $userId = $_POST['userId'];
    $projectId = $_POST['projectId'];
    $checkbox1 = isset($_POST['checkbox1']) ? $_POST['checkbox1'] : 0;
    $checkbox2 = isset($_POST['checkbox2']) ? $_POST['checkbox2'] : 0;
    $checkbox3 = isset($_POST['checkbox3']) ? $_POST['checkbox3'] : 0;
    $checkbox4 = isset($_POST['checkbox4']) ? $_POST['checkbox4'] : 0;
    $checkbox5 =  isset($_POST['checkbox5']) ? $_POST['checkbox5']: 0;
    $checkbox6 =  isset($_POST['checkbox6'])  ? $_POST['checkbox6']: 0;


    // Insert data into the database
    $sql = "INSERT INTO ratings (user_id, project_id, checkbox1, checkbox2, checkbox3, checkbox4, checkbox5, checkbox6) 
            VALUES (?, ?, ?, ?, ?, ?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiiiiii", $userId, $projectId, $checkbox1, $checkbox2, $checkbox3, $checkbox4,$checkbox5,$checkbox6);

    if ($stmt->execute()) {
        // Redirect to the project details page with a success message
        $_SESSION['success_message'] = "Grades submitted successfully!";
        header("Location: adminView.php?viewid=" . $projectId);
        exit(); // Stop script execution
    } else {
        // Redirect to the project details page with an error message
        $_SESSION['error_message'] = "Error submitting grades: " . $stmt->error;
        header("Location: adminView.php?viewid=" . $projectId);
        exit(); // Stop script execution
    }
} else {
    // Redirect to the homepage if the form is not submitted
    header("Location: home.php");
    exit(); // Stop script execution
}
?>
