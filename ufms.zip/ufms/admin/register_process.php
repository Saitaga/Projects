<?php
// Database connection
include 'connection.php';

// Retrieve data from form
//$admin_id = $_POST['admin_id'];
$pfNo = $_POST['pfNo'];
$course = $_POST['course'];
$name = $_POST['name'];
$password = $_POST['password'];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
//$hashedPassword = md5($password);
 // Hash the password

// Insert data into database
$sql = "INSERT INTO admins (pfNo, course, password,name) VALUES ('$pfNo', '$course', '$hashedPassword','$name')";

if ($conn->query($sql) === TRUE) {
    header("Location: admin_login.php?success=Your account has been created successfully");
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
