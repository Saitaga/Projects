<?php
include 'header.php';
include 'connection.php';
?>

<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['pfNo'])) {
    include 'connection.php';
    include 'php/User.php';
    $user = getUserById($_SESSION['id'], $conn);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="projects.css">
    <script src="scripts.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        table {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1 class="text-center mb-5">Manage Projects</h1>
    <hr>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input class="form-control me-2" type="search" name="search" placeholder="Search by Course, Student Name, or Project Title" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </nav>

    <table class="table ">
        <thead>
            <tr>
                <th scope="col">Project Title</th>
                <th scope="col">Student Name</th>
                <th scope="col">Email</th>
                <th scope="col">Course</th>
                <th scope="col">File</th>
                <th scope="col">Action</th>
            </tr>
            <style>
                table {
                    border: 1px solid black;
                }
            </style>
        </thead>

        <?php  
        if (isset($_POST['search'])) {
            $search = $_POST['search'];
            $sql = "SELECT * FROM project WHERE projectTitle LIKE '%$search%' OR studentName LIKE '%$search%' OR course LIKE '%$search%'";
        } else {
            //$id = $_GET['id'];
            $sql = "SELECT * FROM project ORDER BY course"; // Order by course
        }
        
        $result = mysqli_query($conn, $sql);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                //$id = $row['id'];
                $projectTitle = $row['projectTitle'];
                $studentName = $row['studentName'];
                $studentEmail = $row['studentEmail'];
                $course = $row['course'];
                $file = $row['file'];

                echo '<tr>
                    <td>' . $projectTitle . '</td>
                    <td>' . $studentName . '</td>
                    <td>' . $studentEmail . '</td>
                    <td>' . $course . '</td>
                    <td>' . $file . '</td>
                    <td>
                        <button class="btn btn-primary"><a href="view.php?viewid=' . $row['id'] . '" class="text-light">View</a></button>
                    </td>
                </tr>';
            }
        }
        ?>

    </table>
</body>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p class="text-muted">Copyright © 2023 UNDERGRADUATE FINAL YEAR PROJECTS MANAGEMENT SYSTEM</p>
            </div>
            <div class="col-md-6 text-md-right">
                <a href="logout.php" class="btn btn-warning">Logout</a>
                <a href="home.php" class="btn btn-secondary">HOME</a>
            </div>
        </div>
    </div>
    <style>
        .footer {
            background-color: #f5f5f5;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }

        .footer p {
            margin-bottom: 0;
        }

        .logout-btn {
            background-color: #d9534f;
            border-color: #d9534f;
            color: #fff;
        }

        .logout-btn:hover {
            background-color: #c9302c;
            border-color: #c9302c;
            color: #fff;
        }
    </style>
</footer>
</html>

<?php
} else {
    header("Location: login.php");
    exit;
}
?>
