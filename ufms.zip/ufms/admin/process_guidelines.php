
<?php
                        session_start();
                     include 'connection.php';

                    // Check if admin is logged in
                    session_start();
                    if (!isset($_SESSION['admin_id'])) {
                        header("Location: admin_login.php");
                        exit();
                    }
                    // Fetch admin's course
                    $admin_id = $_SESSION['admin_id'];
                    $sql_admin = "SELECT course FROM admins WHERE admin_id=?";
                    $stmt_admin = $conn->prepare($sql_admin);
                    $stmt_admin->bind_param("i", $admin_id);
                    $stmt_admin->execute();
                    $result_admin = $stmt_admin->get_result();
                    $row_admin = $result_admin->fetch_assoc();
                    $course = $row_admin['course'];

                    // Fetch projects based on admin's course
                    $sql_guidelines = "SELECT * FROM guidelines WHERE course=?";
                    $sql_guidelines = $conn->prepare($sql_guidelines);
                    $sql_guidelines->bind_param("s", $course);
                    $sql_guidelines->execute();
                    $sql_guidelines = $sql_guidelines->get_result();

                    if ($result_guidelines->num_rows > 0) {
                        while ($row_guidelines = $result_projects->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row_guidelines['guidelines'] . "</td>";
                            echo "<td>" . $row_project['course'] . "</td>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No projects found.</td></tr>";
                    }

                    // Close statements and connection
                    $stmt_admin->close();
                    $sql_guidelines->close();
                    $conn->close();
                    ?>