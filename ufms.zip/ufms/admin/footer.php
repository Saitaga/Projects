<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* Set height for the body to fill the viewport */
        body {
            height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        /* Main content container */
        .content {
            flex: 1; /* Allow the content to grow and fill the available space */
        }

        /* Footer styling */
        .footer {
            background-color: #f5f5f5;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }

        /* Center the footer content */
        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px; /* Adjust as needed */
            margin: 0 auto; /* Center horizontally */
            padding: 0 20px; /* Add some padding */
        }

        /* Style for footer buttons */
        .footer-btn {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="content">
        <!-- Your main content goes here -->
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div>
                <p class="text-muted">Copyright © 2024 UNDERGRADUATE FINAL YEAR PROJECTS MANAGEMENT SYSTEM</p>
            </div>
            <div>
                <a href="logout.php" class="btn btn-warning footer-btn">Logout</a>
                <a href="home.php" class="btn btn-secondary footer-btn">HOME</a>
            </div>
        </div>
    </footer>
</body>
</html>
