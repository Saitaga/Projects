<?php
// Include the necessary files and establish database connection
include "connection.php";
include "header.php";

// Check if a project ID is provided in the URL
if (isset($_GET['editid'])) {
    $id = $_GET['editid'];

    // Prepare the SQL statement with a placeholder
    $sql = "SELECT * FROM project WHERE id = ?";
    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("i", $id);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if the project exists
    if ($result->num_rows > 0) {
        // Project found, display its details and allow editing
        $row = $result->fetch_assoc();
    
?>
        <div style='text-align: center; margin: 0 auto; max-width: 600px;'>
            <h2>Edit Project File</h2>
            <div style='text-align: left; padding: 20px;  border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'>
                <form action="update_file.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="project_id" value="<?php echo $row['id']; ?>">
                    <p><strong>Name:</strong> <?php echo $row['studentName']; ?></p>
                    <p><strong>Project Title:</strong> <?php echo $row['projectTitle']; ?></p>
                    <p><strong>Course:</strong> <?php echo $row['course']; ?></p>
                    <p><strong>Student Email:</strong> <?php echo $row['studentEmail']; ?></p>
                    <p><strong>File:</strong> <?php echo $row['file']; ?></p>
                    <p><strong>Description:</strong> <?php echo $row['description']; ?></p>
                    <label for="new_file">New File:</label>
                   <input type="file" name="new_file" id="new_file">
                    <button type="submit" name="submit" class="btn btn-primary">Update File</button>

                </form>
            </div>
        </div>
<?php
    } else {
        echo '<div style="text-align: center;">No data found for project ID: ' . $id . '</div>';
    }
}
?>
<div class="text-center mt-4">
    <button onclick="goBack()" class="btn btn-secondary">Back</button>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php
include 'footer.php';
?>

