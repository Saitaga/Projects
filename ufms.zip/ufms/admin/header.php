<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa; /* Slightly dark background */
        }

        .nav-header {
            background-color: #343a40; /* Dark background for header */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Shadow effect */
            border-radius: 8px; /* Rounded corners */
            padding: 10px 20px; /* Add padding for better spacing */
            margin-bottom: 20px; /* Add margin to separate from content */
        }

        .nav-logo {
            display: flex;
            justify-content: center;
            margin-bottom: 10px; /* Add margin for better spacing */
        }

        .nav-logo img {
            max-width: 100px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="nav-header">
        <div class="nav-logo">
            <img src="LOGO2.png" alt="Logo" class="img-fluid">
        </div>
        <nav>
            <div class="container-fluid">
                <div class="dropdown">
                    <a href="home.php" class="btn btn-secondary">Home</a>
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        Menu
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <!-- Projects Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="table.php">
                                <i class="fas fa-folder-open me-2"></i> Projects
                            </a>
                        </li>
                        <!-- Profile Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="forum/index.php">
                                <i class="fas fa-user-edit me-2"></i> Guidelines
                            </a>
                        </li>
                        <!-- Status Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="approved.php">
                                <i class="fas fa-info-circle me-2"></i> Status
                            </a>
                        </li>
                        <!-- Users Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="students.php">
                                <i class="fas fa-users me-2"></i> Users
                            </a>
                        </li>
                        <!-- Add Users Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="index.php">
                                <i class="fas fa-user-plus me-2"></i> Add Users
                            </a>
                        </li>
                        <!-- Log Out Dropdown Item -->
                        <li>
                            <a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Log Out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
