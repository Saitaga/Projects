<?php
include 'connection.php';
$id=$_GET['updateid'];
if(isset($_POST['submit'])){
    $projectTitle=$_POST['projectTitle'];
    $studentName=$_POST['studentName'];
    $studentEmail=$_POST['studentEmail'];
    $course=$_POST['course'];
    $file=$_POST['file'];
    $pname=rand(1000,10000)."-".$_FILES["file"]["name"];
    $file=$_FILES["files"]["tmp_name"];

    $uploads_dir = '/uploads';

    move_uploaded_file($tname,$uploads_dir.'/'.$pname);

    $sql="update project set id=$id,projectTitle='$projectTitle',studentName='$studentName',
    studentEmail='$studentEmail',course='$course',file='$file' where id=$id";
    $result = $conn->query($sql);
    if($result){
        //echo "Data inserted successfully";
        header('location:table.php');
    }else{
    die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        table {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Add Project</h1><hr>
        <form action="table.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="projectTitle">Project Title:</label>
                <input type="text" class="form-control" id="projectTitle" name="projectTitle" 
                autocomplete="off" value="<?php echo $projectTitle;?>" placeholder="e.g. learning management system" required>
            </div>
            <div class="form-group">
                <label for="studentName">Student Name:</label>
                <input type="text" class="form-control" id="studentName" name="studentName" 
                autocomplete="off" value="<?php echo $studentName;?>" placeholder="e.g. martin maasai"  required>
            </div>
            <div class="form-group">
                <label for="course">Course:</label>
                <input type="text" class="form-control" id="course" name="course" 
                autocomplete="off" value="<?php echo $course;?>" placeholder="e.g. Information Technology" required>
            </div>
            <div class="form-group">
                <label for="studentEmail">Student Email:</label>
                <input type="email" class="form-control" id="studentEmail" name="studentEmail" 
                autocomplete="off" value="<?php echo $studentEmail;?>" placeholder="e.g. martinmaasai@gmail.com" required>
            </div>
            <div class="form-group">
                <label for="chapter">Chapter:</label>
                <input type="text" class="form-control" id="chapter" name="chapter" 
                autocomplete="off" value="<?php echo $chapter;?>" placeholder="e.g. Chapter Four" required>
            </div>
            <div class="form-group">
                <label for="file">Upload Project File:</label>
                <input type="file" class="form-control-file" id="file" name="file" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Update</button>
            <button class="btn btn-danger"><a href="table.php"class="text-light">Back</a></button>

        </form>
    </div>
    <?php

    ?>
   
</body>
</html>
